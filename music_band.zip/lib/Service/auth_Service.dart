//8MpyiLrULhVxZULMrgPKDOPAKJu1

import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth;
  AuthService(this._auth);

  Stream<User> get authStateChanges => _auth.idTokenChanges();
  Future<String> Signup(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      return "Successfully";
    } catch (e) {
      return e;
    }
  }
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:music/Activity/band_booking.dart';

class BandList extends StatefulWidget {
  @override
  _BandListState createState() => _BandListState();
}

class _BandListState extends State<BandList> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      width: double.infinity,
      height: double.infinity,
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                    fit: BoxFit.fill,
                    image: NetworkImage(
                        "https://firebasestorage.googleapis.com/v0/b/musicband-a2793.appspot.com/o/background%2Fbackground.jpg.jpg?alt=media&token=1b63a038-0957-4d95-85a0-103d73933caa"))),
            height: MediaQuery.of(context).size.height / 3,
          ),
          Padding(
            padding: const EdgeInsets.all(2.0),
            child: Text(
              "😊 Singers 😊",
              style: TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                  fontStyle: FontStyle.italic),
            ),
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('bandlist')
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return ListView(
                      shrinkWrap: true,
                      children: snapshot.data.docs.map((document) {
                        return Column(
                          children: [
                            Card(
                              elevation: 10.0,
                              child: Column(
                                children: [
                                  ListTile(
                                    leading: CircleAvatar(
                                      radius: 30.0,
                                      backgroundColor: Colors.blueGrey,
                                      backgroundImage:
                                          NetworkImage(document['image']),
                                    ),
                                    title: Text(
                                      document['name'],
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    trailing: ElevatedButton(
                                      child: Text("Booking"),
                                      onPressed: () {
                                        Navigator.push(context,
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return BandBooking(
                                            singer: document['name'],
                                            image: document['image'],
                                          );
                                        }));
                                      },
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 7.0,
                            )
                          ],
                          //child: Center(child: Text(document['name'])),
                        );
                      }).toList(),
                    );
                  }),
            ),
          ))
        ],
      ),
    ));
  }
}

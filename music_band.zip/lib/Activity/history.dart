import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class History extends StatefulWidget {
  @override
  _HistoryState createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  String userid = "";
  getUserid() async {
    SharedPreferences sharepre = await SharedPreferences.getInstance();
    setState(() {
      userid = sharepre.getString("Auth_userid");
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserid();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: double.infinity,
          width: double.infinity,
          child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('bookingdata')
                  .where("userid", isEqualTo: userid)
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: Text(
                      "No data",
                      style: TextStyle(
                          fontStyle: FontStyle.italic,
                          fontSize: 15.0,
                          color: Colors.blue),
                    ),
                  );
                } else {
                  return ListView(
                    shrinkWrap: true,
                    children: snapshot.data.docs.map((document) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0)),
                                clipBehavior: Clip.antiAlias,
                                elevation: 10.0,
                                child: Container(
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: NetworkImage(
                                                "https://firebasestorage.googleapis.com/v0/b/musicband-a2793.appspot.com/o/background%2Fcard.png?alt=media&token=b10acb22-2714-4892-8ea8-d447b11cf80c"))),
                                    width: double.infinity,
                                    height: 150.0,
                                    child: Stack(
                                      children: <Widget>[
                                        Positioned(
                                          top: 2,
                                          left: 50,
                                          child: Text(
                                            "Booked",
                                            style: TextStyle(
                                                color: Colors.blue,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15.0),
                                          ),
                                        ),
                                        Positioned(
                                            top: 35,
                                            left: 20,
                                            child: Text(
                                              document['singername'],
                                              style: TextStyle(
                                                  color: Colors.deepPurple,
                                                  fontSize: 20.0,
                                                  fontStyle: FontStyle.italic),
                                            )),
                                        Positioned(
                                            top: 65,
                                            left: 20,
                                            child: Text(
                                              "₹ ${document['cost']}",
                                              style: TextStyle(
                                                  fontSize: 15.0,
                                                  fontStyle: FontStyle.italic),
                                            )),
                                        Positioned(
                                            top: 105,
                                            left: 25,
                                            child: Text(
                                              "Date : ${document['show']}",
                                              style: TextStyle(
                                                  fontSize: 15.0,
                                                  fontStyle: FontStyle.italic),
                                            )),
                                        Positioned(
                                          top: 25,
                                          right: 35,
                                          child: CircleAvatar(
                                            radius: 50.0,
                                            backgroundColor: Colors.blueGrey,
                                            backgroundImage:
                                                NetworkImage(document['image']),
                                          ),
                                        ),
                                      ],
                                    )),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  );
                }
              })

          /* Card(
          elevation: 10.0,
          child: Container(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [Text("name"), Text("done")],
                ),
                SizedBox(
                  height: 10.0,
                ),
                Row(
                  children: [Text("name"), Text("done")],
                ),
                SizedBox(
                  height: 10.0,
                ),
                Row(
                  children: [Text("name"), Text("done")],
                )
              ],
            ),
          ),
        ),*/
          ),
    );
  }
}

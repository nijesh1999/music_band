import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:music/main.dart';

import 'home.dart';

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  String temp = "";
  String email = "";
  String pass = "";
  bool val = false;
  bool hidePassword = true;
  bool hideConfirm = true;
  final GlobalKey<FormState> formkey = GlobalKey();
  final TextEditingController _pass = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  void signup() async {
    await _auth.createUserWithEmailAndPassword(
        email: email.trim(), password: pass.trim());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Signup"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Container(
            width: double.infinity,
            height: double.infinity,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Container(
                    width: double.infinity,
                    child: Column(
                      children: [
                        Text(
                          "Sign up",
                          style: TextStyle(
                              color: Colors.blue,
                              fontSize: 25.0,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Form(
                          key: formkey,
                          child: Column(
                            children: [
                              TextFormField(
                                decoration: InputDecoration(
                                  labelText: "Email",
                                  labelStyle: new TextStyle(color: Colors.blue),
                                ),
                                validator: (input) {
                                  if (input.isEmpty) {
                                    return "enter the email";
                                  } else if (!input.contains("@")) {
                                    return 'Invalid Email';
                                  }
                                  return null;
                                },
                                onSaved: (input) {
                                  setState(() {
                                    email = input;
                                    print(email);
                                  });
                                },
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              TextFormField(
                                controller: _pass,
                                obscureText: hidePassword,
                                decoration: InputDecoration(
                                    labelText: "Password",
                                    labelStyle:
                                        new TextStyle(color: Colors.blue),
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        hidePassword
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: Colors.blue,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          hidePassword = !hidePassword;
                                        });
                                      },
                                    )),
                                validator: (input) {
                                  if (input.isEmpty || input.length < 6) {
                                    return "password minmum 6 characters";
                                  }
                                  return null;
                                },
                                onSaved: (input) {
                                  setState(() {
                                    this.pass = input;
                                    print(pass);
                                  });
                                },
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              TextFormField(
                                obscureText: hideConfirm,
                                decoration: InputDecoration(
                                    labelText: "Confirm Password",
                                    labelStyle:
                                        new TextStyle(color: Colors.blue),
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        hideConfirm
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: Colors.blue,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          hideConfirm = !hideConfirm;
                                        });
                                      },
                                    )),
                                validator: (input) {
                                  if (input.isEmpty) {
                                    return "this feild mandatory";
                                  } else if (input != _pass.text) {
                                    // print(input);
                                    print(temp);
                                    return "incorrect confirm password";
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              Container(
                                child: ButtonTheme(
                                  buttonColor: Colors.blue,
                                  height: 50.0,
                                  minWidth: double.infinity,
                                  child: RaisedButton(
                                    onPressed: () async {
                                      FocusScope.of(context).unfocus();
                                      if (validateAndSave()) {
                                        signup();
                                        final snackbar = SnackBar(
                                          backgroundColor: Colors.blue,
                                          content: Text(
                                            "Register successfully",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          padding: const EdgeInsets.all(5.0),
                                          behavior: SnackBarBehavior.floating,
                                          action: SnackBarAction(
                                            label: "undo",
                                            onPressed: () {},
                                          ),
                                        );
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(snackbar);
                                        Navigator.push(context,
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return Login();
                                        }));
                                      }
                                    },
                                    child: Text(
                                      "Signup",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20.0,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  bool validateAndSave() {
    formkey.currentState.validate();
    if (formkey.currentState.validate()) {
      formkey.currentState.save();
      return true;
    }
    return false;
  }
}

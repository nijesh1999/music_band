import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:music/Activity/band_list.dart';
import 'package:music/Activity/history.dart';
import 'package:music/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Home extends StatefulWidget {
  final String current_email;

  const Home({Key key, this.current_email}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  int currentIndex = 0;
  String title = "Music Band Booking";
  String temp = "";

  getUser() async {
    SharedPreferences sharepre = await SharedPreferences.getInstance();
    setState(() {
      temp = sharepre.getString("email") == null
          ? widget.current_email
          : sharepre.getString("email");
    });
  }

  Widget getCurrent() {
    switch (currentIndex) {
      case 0:
        return BandList();
        break;
      case 1:
        return History();
        break;
    }
  }

  setCurrentIndex(int index) {
    setState(() {
      currentIndex = index;
    });
    Navigator.of(context).pop();
  }

  Future<bool> Pressback() {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("do you want to exit"),
            actions: <Widget>[
              FlatButton(
                  onPressed: () {
                    return Navigator.pop(context, true);
                  },
                  child: Text("yes")),
              FlatButton(
                  onPressed: () {
                    return Navigator.pop(context, false);
                  },
                  child: Text("no")),
            ],
          );
        });
  }

  Future<void> logout() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("do you want to logout"),
            actions: <Widget>[
              FlatButton(
                  onPressed: () async {
                    await _auth.signOut();
                    SharedPreferences sharepre =
                        await SharedPreferences.getInstance();
                    sharepre.clear();
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return MyApp();
                    }));
                  },
                  child: Text("yes")),
              FlatButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("no")),
            ],
          );
        });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUser();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: Pressback,
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
        ),
        drawer: Drawer(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                accountEmail: Text(temp),
                currentAccountPicture: CircleAvatar(
                  radius: 30.0,
                  backgroundColor: Colors.white,
                  backgroundImage: NetworkImage(
                      "https://firebasestorage.googleapis.com/v0/b/musicband-a2793.appspot.com/o/background%2Fuser.png?alt=media&token=ef9a79a6-bb68-4b1d-8d24-6029ba0cc0b0"),
                ),
              ),
              ListTile(
                title: Text("music band"),
                leading: Icon(Icons.music_note),
                selected: currentIndex == 0 ? true : false,
                onTap: () {
                  setCurrentIndex(0);
                  title = "Music Band Booking";
                },
              ),
              ListTile(
                title: Text("history"),
                leading: Icon(Icons.history_edu_sharp),
                selected: currentIndex == 1 ? true : false,
                onTap: () {
                  setCurrentIndex(1);
                  title = "History";
                },
              ),
              ListTile(
                title: Text("logout"),
                leading: Icon(Icons.login_outlined),
                selected: false,
                onTap: () {
                  logout();
                },
              ),
            ],
          ),
        ),
        body: getCurrent(),
      ),
    );
  }
}

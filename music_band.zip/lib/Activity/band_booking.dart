import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:music/Activity/home.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BandBooking extends StatefulWidget {
  final String singer;
  final String image;

  const BandBooking({Key key, this.singer, this.image}) : super(key: key);

  @override
  _BandBookingState createState() => _BandBookingState();
}

class _BandBookingState extends State<BandBooking> {
  String name = "";
  double cost = 0;
  String city = "";
  int pin = 0;
  int contact = 0;
  String _dateTime = "";
  final GlobalKey<FormState> formkey = GlobalKey();

  @override
  void initState() {
    super.initState();
    setData();
  }

  setData() {
    DateTime date = DateTime.now();
    setState(() {
      _dateTime = ("${date.day}-${date.month}-${date.year}").toString();
    });
  }

  pickdate() async {
    DateTime date = await showDatePicker(
        context: context,
        firstDate: DateTime.now(),
        initialDate: DateTime.now(),
        lastDate: DateTime(DateTime.now().year + 5));
    if (date != null) {
      setState(() {
        _dateTime = ("${date.day}-${date.month}-${date.year}").toString();
      });
    }
  }

  Future<void> databooking() async {
    SharedPreferences sharepre = await SharedPreferences.getInstance();
    var login_id = sharepre.getString("Auth_userid");
    QuerySnapshot qs = await FirebaseFirestore.instance
        .collection('bookingdata')
        .where('singername', isEqualTo: widget.singer)
        .where('show', isEqualTo: (_dateTime))
        .get();

    if (qs.size > 0) {
      return showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text(
                "singer not available",
                style: TextStyle(color: Colors.red),
              ),
              actions: <Widget>[
                FlatButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text("ok")),
              ],
            );
          });
    } else {
      FirebaseFirestore.instance.collection('bookingdata').add({
        'singername': widget.singer,
        'show': _dateTime,
        'name': name.trim(),
        'city': city.trim(),
        'cost': cost,
        'pin': pin,
        'image': widget.image,
        'contact': contact,
        'userid': login_id
      });
      return showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text(
                "Booking successfully...😊",
                style: TextStyle(color: Colors.green),
              ),
              actions: <Widget>[
                FlatButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return Home();
                      }));
                    },
                    child: Text("ok")),
              ],
            );
          });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking"),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Container(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      "Booking Details",
                      style: TextStyle(
                          fontSize: 18.0,
                          fontStyle: FontStyle.italic,
                          color: Colors.blue,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  SizedBox(
                    height: 13.0,
                  ),
                  Form(
                      key: formkey,
                      child: Column(
                        children: [
                          TextFormField(
                            decoration: InputDecoration(
                                labelText: "Name",
                                labelStyle: new TextStyle(color: Colors.blue),
                                border: OutlineInputBorder()),
                            validator: (input) {
                              if (input.isEmpty) {
                                return "enter the name";
                              }
                              return null;
                            },
                            onSaved: (input) {
                              setState(() {
                                name = input;
                              });
                            },
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          TextFormField(
                            decoration: InputDecoration(
                                labelText: "City",
                                labelStyle: new TextStyle(color: Colors.blue),
                                border: OutlineInputBorder()),
                            validator: (input) {
                              if (input.isEmpty) {
                                return "enter the city";
                              }
                              return null;
                            },
                            onSaved: (input) {
                              setState(() {
                                city = input;
                              });
                            },
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                                labelText: "Cost",
                                labelStyle: new TextStyle(color: Colors.blue),
                                border: OutlineInputBorder()),
                            validator: (input) {
                              if (input.isEmpty) {
                                return "enter the cost";
                              }
                              return null;
                            },
                            onSaved: (input) {
                              setState(() {
                                cost = double.parse(input);
                              });
                            },
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                                labelText: "Contact",
                                labelStyle: new TextStyle(color: Colors.blue),
                                border: OutlineInputBorder()),
                            validator: (input) {
                              if (input.isEmpty) {
                                return "enter the contact";
                              }
                              return null;
                            },
                            onSaved: (input) {
                              setState(() {
                                contact = int.parse(input);
                              });
                            },
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            maxLength: 6,
                            decoration: InputDecoration(
                                labelText: "Postal code",
                                labelStyle: new TextStyle(color: Colors.blue),
                                border: OutlineInputBorder()),
                            validator: (input) {
                              if (input.isEmpty) {
                                return "enter the pin";
                              }
                              return null;
                            },
                            onSaved: (input) {
                              setState(() {
                                pin = int.parse(input);
                              });
                            },
                          ),
                          SizedBox(height: 10.0),
                          ListTile(
                            title: Text(_dateTime),
                            trailing: IconButton(
                              onPressed: () {
                                pickdate();
                              },
                              icon: Icon(Icons.calendar_today_rounded),
                              color: Colors.blue,
                            ),
                          ),
                          SizedBox(
                            height: 15.0,
                          ),
                          Container(
                            child: ButtonTheme(
                              buttonColor: Colors.blue,
                              height: 50.0,
                              minWidth: double.infinity,
                              child: RaisedButton(
                                onPressed: () {
                                  FocusScope.of(context).unfocus();
                                  if (validateAndSave()) {
                                    FocusScope.of(context).unfocus();
                                    databooking();
                                  }
                                },
                                child: Text(
                                  "Booking",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  bool validateAndSave() {
    formkey.currentState.validate();
    if (formkey.currentState.validate()) {
      formkey.currentState.save();
      return true;
    }
    return false;
  }
}

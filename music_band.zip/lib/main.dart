import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/services.dart';
import 'Activity/Signup.dart';
import 'Activity/home.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SharedPreferences sharepre = await SharedPreferences.getInstance();
  var login_id = sharepre.getString("Auth_userid");
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: login_id == null ? MyApp() : Home(),
  ));
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Login(),
    );
  }
}

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String email = "";
  String pass = "";
  bool val = false;
  bool hidePassword = true;
  final GlobalKey<FormState> formkey = GlobalKey();

  void signin() async {
    await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: pass)
        .catchError((onError) {
      final snackbar = SnackBar(
        backgroundColor: Colors.blue,
        content: Text(
          "Invalid username and password",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        padding: const EdgeInsets.all(5.0),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: "undo",
          onPressed: () {},
        ),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackbar);
    }).then((authUser) async {
      print(authUser.user.uid);
      if (val == true) {
        SharedPreferences sharepre = await SharedPreferences.getInstance();
        sharepre.setString("Auth_userid", authUser.user.uid);
        sharepre.setString("email", email);
      }
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return Home(
          current_email: email,
        );
      }));
    });
  }

  Future<bool> Pressback() {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("do you want to exit"),
            actions: <Widget>[
              FlatButton(
                  onPressed: () {
                    return Navigator.pop(context, true);
                  },
                  child: Text("yes")),
              FlatButton(
                  onPressed: () {
                    return Navigator.pop(context, false);
                  },
                  child: Text("no")),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: Pressback,
      child: Scaffold(
        body: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Container(
            height: double.infinity,
            width: double.infinity,
            child: Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Container(
                    width: double.infinity,
                    child: Column(
                      children: [
                        Text(
                          "Login",
                          style: TextStyle(
                              color: Colors.blue,
                              fontSize: 25.0,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Form(
                          key: formkey,
                          child: Column(
                            children: [
                              TextFormField(
                                decoration: InputDecoration(
                                    labelText: "Email",
                                    labelStyle:
                                        new TextStyle(color: Colors.blue),
                                    border: OutlineInputBorder()),
                                validator: (input) {
                                  if (input.isEmpty) {
                                    return "enter the email";
                                  } else if (!input.contains("@")) {
                                    return 'Invalid Email';
                                  }
                                  return null;
                                },
                                onSaved: (input) {
                                  setState(() {
                                    email = input;
                                  });
                                },
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                obscureText: hidePassword,
                                decoration: InputDecoration(
                                    labelText: "Password",
                                    labelStyle:
                                        new TextStyle(color: Colors.blue),
                                    border: OutlineInputBorder(),
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        hidePassword
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: Colors.blue,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          hidePassword = !hidePassword;
                                        });
                                      },
                                    )),
                                validator: (input) {
                                  if (input.isEmpty || input.length < 6) {
                                    return "password minmum 6 characters";
                                  }
                                  return null;
                                },
                                onSaved: (input) {
                                  setState(() {
                                    pass = input;
                                  });
                                },
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Checkbox(
                                      value: this.val,
                                      onChanged: (bool value) {
                                        setState(() {
                                          this.val = value;
                                        });
                                      }),
                                  SizedBox(
                                    width: 5.0,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        this.val = !this.val;
                                      });
                                    },
                                    child: Text(
                                      "Remember me",
                                      style: TextStyle(
                                          color: Color.fromRGBO(68, 68, 68, 1),
                                          fontSize: 18.0),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              Container(
                                child: ButtonTheme(
                                  buttonColor: Colors.blue,
                                  height: 50.0,
                                  minWidth: double.infinity,
                                  child: RaisedButton(
                                    onPressed: () {
                                      FocusScope.of(context).unfocus();
                                      if (validateAndSave()) {
                                        signin();

                                        // print("email=${email} pass=${pass}");
                                      }
                                    },
                                    child: Text(
                                      "Login",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20.0,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 10.0,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Don't have an account ?",
                                      style: TextStyle(fontSize: 18.0),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.push(context,
                                            MaterialPageRoute(
                                                builder: (context) {
                                          return Signup();
                                        }));
                                      },
                                      child: Text(
                                        "Sign up",
                                        style: TextStyle(
                                            color: Colors.blue,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18.0),
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  bool validateAndSave() {
    formkey.currentState.validate();
    if (formkey.currentState.validate()) {
      formkey.currentState.save();
      return true;
    }
    return false;
  }
}
